<?php
return [
    'Axioma\Customizations\Applications\CategoriedEntitySellector\PageManager',
];